<?php if(!defined('DNREAD')) exit();
// SEO LINKING
$seo = array();
