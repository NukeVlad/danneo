<?php if(!defined('ADMREAD')) exit();
// SETTINGS
define("SKIN_DEF", 'Lite');
define("VERSION", '1.5.0');
define("CHAR_DEF", 'utf-8');
define("CODE_DEF", 'ru');
define("LIFE_ADMIN", '14400');
// LANGUAGE
$lang = array(
'adm_login' => 'Логин',
'adm_passw' => 'Пароль',
'adm_enter' => 'Войти',
'adm_panel' => 'Панель управления сайтом',
'adm_auth_error' => 'Ошибка авторизации!<br /> Неправильный логин или пароль',
'adm_sess_out' => 'Отсутствие активности более {lifeadmin} секунд<br /> Пожалуйста, авторизуйтесь заново',
'adm_delsetup' => 'В целях безопасности удалите каталог',
'chmod_config' => 'Установите права (только для чтения) на файл',
'adm_bad_agent' => 'Вы используете устаревшую версию браузера.<br /> Для полноценной работы в панели управления требуется версия IE не ниже 8.0',
'adm_non_cookie' => 'Ошибка авторизации!<br /> Возможно, в вашем браузере отключены Cookies',
'adm_bad_cookie' => 'В вашем браузере отключены Cookies!',
'adm_noscript' => 'В вашем браузере отключенна поддержка JavaScript<br />Некоторые функции будут недоступны'
);
define('CACHELOGIN', 1);
?>