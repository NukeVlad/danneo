<?php if(!defined('DNREAD')) exit();
// CACHE MENU
$array_menu = array('1'=>array('code'=>'dnmtop','name'=>'Верхнее меню','link'=>'','title'=>'','icon'=>'','css'=>'dnmtop','target'=>'','sub'=>array('4'=>array('code'=>'','name'=>'Главная','link'=>'','title'=>'','icon'=>'','css'=>'','target'=>'_self',),),),'2'=>array('code'=>'dnmblock','name'=>'Блочное меню','link'=>'','title'=>'','icon'=>'','css'=>'js-block-menu','target'=>'',),'3'=>array('code'=>'botmenu','name'=>'Нижнее меню','link'=>'','title'=>'','icon'=>'','css'=>'bot-menu','target'=>'',),);
