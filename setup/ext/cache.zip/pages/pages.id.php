<?php if(!defined('DNREAD')) exit();
return array(
'company'=>'1'
);
