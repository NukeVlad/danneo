<?php if(!defined('DNREAD')) exit();
// catalog option
$option = array(
'1'=>array('title'=>'Платформа','type'=>'checkbox','search'=>'0','buy'=>'1','value'=>array('2'=>array('title'=>'PC','modify'=>'not','modvalue'=>'0.0000'),'4'=>array('title'=>'X360','modify'=>'fix','modvalue'=>'504.6000'),'16'=>array('title'=>'PS3','modify'=>'fix','modvalue'=>'1000.0000'),'13'=>array('title'=>'Wii','modify'=>'fix','modvalue'=>'800.0000'),'14'=>array('title'=>'PSP','modify'=>'fix','modvalue'=>'600.0000'),'6'=>array('title'=>'NDS','modify'=>'fix','modvalue'=>'400.0000'))),
'4'=>array('title'=>'Тип издания','type'=>'select','search'=>'1','buy'=>'1','value'=>array('1'=>array('title'=>'Обычное','modify'=>'not','modvalue'=>'0.0000'),'7'=>array('title'=>'Расширеннное','modify'=>'fix','modvalue'=>'50.0000'),'8'=>array('title'=>'Премиум','modify'=>'fix','modvalue'=>'100.0000'),'10'=>array('title'=>'Дополнительное','modify'=>'not','modvalue'=>'0.0000'))),
'3'=>array('title'=>'Язык интерфейса','type'=>'select','search'=>'1','buy'=>'1','value'=>array('17'=>array('title'=>'Русский','modify'=>'not','modvalue'=>'0.0000'),'3'=>array('title'=>'Английский','modify'=>'fix','modvalue'=>'100.0000'),'5'=>array('title'=>'Немецкий','modify'=>'not','modvalue'=>'0.0000'),'11'=>array('title'=>'Французкий','modify'=>'not','modvalue'=>'0.0000'),'15'=>array('title'=>'Испанский','modify'=>'not','modvalue'=>'0.0000'))),
'8'=>array('title'=>'Мультиплеер','type'=>'radio','search'=>'0','buy'=>'1','value'=>array()),
'6'=>array('title'=>'Альтернативное название','type'=>'text','search'=>'0','buy'=>'0','value'=>array()),
'7'=>array('title'=>'В официальной продаже','type'=>'text','search'=>'0','buy'=>'0','value'=>array()),
'5'=>array('title'=>'В официальной продаже в России','type'=>'text','search'=>'0','buy'=>'0','value'=>array()),
'9'=>array('title'=>'Минимальные системные требования','type'=>'text','search'=>'0','buy'=>'0','value'=>array()),
'2'=>array('title'=>'Рекомендуемые системные требования','type'=>'text','search'=>'0','buy'=>'0','value'=>array()));
